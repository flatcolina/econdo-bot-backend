# Deploy Backend eCondo-bot no Render via GitHub

## 1. Crie um repositório no GitHub

- Acesse [https://github.com/](https://github.com/)
- Clique no "+" no topo direito > "New repository"
- Nomeie, por exemplo: `econdo-bot-backend`
- Deixe como "Public" ou "Private"
- **NÃO** marque README, .gitignore ou license
- Clique em "Create repository"

---

## 2. Suba os arquivos do backend para o GitHub

No seu computador:

### a) Abra o terminal/cmd/powershell

Entre na pasta do projeto:

```bash
cd /CAMINHO/ONDE/SALVOU/econdo-bot-backend
